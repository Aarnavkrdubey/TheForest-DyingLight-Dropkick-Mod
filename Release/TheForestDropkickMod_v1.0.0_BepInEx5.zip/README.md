# Dying Light-Style Dropkick Mod for The Forest (2018)

A complete, installable C# gameplay modification for the original **The Forest (2018)** powered by **BepInEx 5 (x64)** and **Harmony**.

This mod brings the iconic airborne two-legged dropkick from *Dying Light* into *The Forest*, while cleanly remapping all original `E` interactions (`Take` and `Build`) and UI interaction prompts to `V`.

---

## 1. Controls & Keybindings

| Key | Action | Details |
| :--- | :--- | :--- |
| **`E`** | **Airborne Dropkick** | Press **`E`** while airborne (after jumping with `Space`) to thrust both legs forward into a Dying Light-style dropkick. |
| **`V`** | **All Original `E` Interactions** | Replaces `E` for all interactions: picking up items/resources, opening doors, adding materials to structures/blueprints, climbing ropes, using boats/rafts/log sleds, picking up animals, eating/drinking, etc. |
| **`Shift`** | **Sprint** | Sprinting before jumping into a dropkick activates the **Sprint Momentum Bonus** (stronger forward boost, +35% physical damage, and stronger enemy knockback). |
| **`Space`** | **Jump** | Standard jump. |

* **Dynamic UI Prompt Updates**: In-game interaction icons (`ActionIconSystem` / `InputMappingIcons`) automatically update to display **`V`** instead of **`E`**.
* **Menu & Chat Safe**: Does not swap keys at the OS level and never interferes with pause menus, inventory, survival book, or multiplayer chat input (`ChatBox.IsChatOpen`).
* **100% Reversible**: Temporarily restores original bindings before `InputMapping.SaveAllMaps` writes to `PlayerPrefs` (`UserRemapping_v3`), so your save files and control settings are never permanently altered.

---

## 2. Dropkick Mechanics, Animation & Combat Physics

1. **Airborne Activation & Balancing**:
   - Press `Space` to jump, then press `E` while airborne.
   - Works from a standing/walking jump, and gains a **Sprint Momentum Bonus** when jumping out of a sprint (`Shift`).
   - **Forward Boost**: `7.2 m/s` base (`~8.8 m/s` when sprinting), configurable (`6–9 m/s` recommended).
   - **Duration**: `0.54s` (`Startup` -> `ActiveKick` -> `Recovery`), configurable (`0.4–0.7s`).
   - **Cooldown**: `1.2s` between dropkicks.
   - **Stamina Cost**: `16` stamina per activation (configurable).
   - **Restrictions**: Maximum **1 dropkick per jump**. Blocked when grounded, swimming/diving, climbing ropes/cliffs, sitting, pushing a sled, sailing a raft, using the glider/turtle shell, incapacitated, in cutscenes, or when menus/inventory/book/chat are open.
2. **Believable Two-Legged Procedural Skeletal Animation**:
   - Directly animates *The Forest*'s verified player rig (`char_Hips`, `char_Spine`, `char_Spine1`, `char_Spine2`, `char_Neck`, `char_Head1`, `char_LeftUpLeg`, `char_LeftLeg`, `char_LeftFoot`, `char_LeftToeBase`, `char_RightUpLeg`, `char_RightLeg`, `char_RightFoot`, `char_RightToeBase`, `char_LeftArm`, `char_LeftForeArm`, `char_RightArm`, `char_RightForeArm`) in `LateUpdate` after Unity's `Animator` evaluation.
   - **Startup Phase**: Knees tuck rapidly toward the chest while the torso begins leaning back.
   - **Active Kick / Impact Phase**: Pelvis shifts forward and both legs thrust straight out along the attack direction—visibly extending both boots into the lower center of the first-person viewport while the upper body leans backward (`~30°`) and arms spread for balance.
   - **Recovery Phase**: Legs smoothly retract beneath the hips and blend back to normal movement prior to landing.
3. **First-Person Camera & Audio Feedback**:
   - Subtle first-person camera pitch/roll and a `+3.8°` FOV punch during extension.
   - Configurable damped impact camera shake (`Off`, `Low`, `Medium`, `High`; default `Low`).
   - Uses authentic game FMOD audio (`PlayerSfx.PlayJumpSound()`, `PlayerSfx.PlayWhoosh()`, weapon `fleshHitEvent` / `smashHitEvent`, and `Mood.HitRumble()`).
4. **Enemy Hit Detection & Knockback Physics**:
   - Continuous non-tunneling `Physics.SphereCastAll` sweeps between frames along `char_LeftFoot`, `char_RightFoot`, and the forward kick volume, plus `Physics.OverlapCapsule` / `OverlapSphere`.
   - Line-of-sight wall occlusion checks (`Physics.RaycastAll`) prevent hitting enemies through solid walls or structures.
   - Per-dropkick enemy deduplication (`HashSet<int>`) guarantees a single dropkick never damages the same enemy twice.
   - **Normal Cannibals**: Receives configurable physical damage (`42` base, `~55` sprinting), strong momentum-scaled physical knockback displacement along terrain (`CharacterController.Move` with wall collision checks), and triggers full knockdown (`EnemyHealth.hitFallDown`).
   - **Heavy Creepy Mutants (Armsy, Virginia, Cowman)**: Receives damage, reduced mass-appropriate knockback (`0.32x`), and triggers heavy stagger (`hitStagger` / `pmCombat` stagger).
   - **Multiplayer Support**: Sends `PlayerHitEnemy` Bolt network packets (`hitFallDown = true`, `getCombo = 3`, `getAttackDirection = 5`, `getAttackerType = 4`) when playing as a client.

---

## 3. Project Structure

```text
TheForestDropkickMod/
├── TheForestDropkickMod.csproj          # MSBuild project targeting The Forest's Mono/.NET runtime
├── build.ps1                            # One-click PowerShell build script
├── install.ps1                          # One-click installer script
├── uninstall.ps1                        # One-click uninstaller & keybinding restorer
├── config/
│   └── com.theforest.dyinglightdropkick.cfg  # Default configuration file
├── Properties/
│   └── AssemblyInfo.cs                  # Assembly metadata
├── src/
│   ├── DropkickModPlugin.cs             # Main BepInEx plugin entry point & lifecycle
│   ├── ModConfig.cs                     # Configuration bindings, validation & hot-reload watcher
│   ├── DebugLogger.cs                   # Conditional diagnostic logging
│   ├── GameReflection.cs                # Pre-cached reflection handles for non-public fields
│   ├── InputRemapManager.cs             # Rewired E->V remapping, UI icon sync & SaveAllMaps guard
│   ├── DropkickStateMachine.cs          # Airborne state machine, physics velocity & wall checks
│   ├── DropkickAnimator.cs              # Procedural two-legged skeletal animation on char_* bones
│   ├── DropkickCameraFeedback.cs        # First-person camera tilt, FOV punch, shake & FMOD audio
│   ├── DropkickHitDetector.cs           # Non-tunneling foot collision sweeps & wall occlusion check
│   ├── EnemyCombatIntegration.cs        # Cannibal/mutant damage, knockdown/stagger & knockback
│   └── RuntimeSelfTest.cs               # In-engine automated verification suite
├── bin/Release/
│   └── TheForestDropkickMod.dll         # Compiled mod assembly
└── Release/
    └── TheForestDropkickMod_v1.0.0_BepInEx5.zip  # Complete ready-to-install bundle (BepInEx + Mod)
```

---

## 4. Installation & Loading Instructions

### Status on This PC
The mod and **BepInEx 5.4.23.5 (x64)** have **already been installed** directly into your game folder:
`C:\Program Files (x86)\Steam\steamapps\common\The Forest`

> **Note on ReShade Compatibility**: Your game folder contains `dxgi.dll` (ReShade). BepInEx 5 uses `winhttp.dll` (UnityDoorstop), which coexists with `dxgi.dll` without any conflict and never modifies original files in `TheForest_Data\Managed\`.

### Manual / Fresh Installation Steps
1. Extract `Release\TheForestDropkickMod_v1.0.0_BepInEx5.zip` directly into your *The Forest* installation folder (`C:\Program Files (x86)\Steam\steamapps\common\The Forest`), **or** run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File "C:\Users\aarna\Downloads\TheForestDropkickMod\install.ps1"
   ```
2. Verify the following files are present in `C:\Program Files (x86)\Steam\steamapps\common\The Forest`:
   - `winhttp.dll`
   - `doorstop_config.ini`
   - `BepInEx\core\...`
   - `BepInEx\plugins\TheForestDropkickMod\TheForestDropkickMod.dll`
   - `BepInEx\config\com.theforest.dyinglightdropkick.cfg`

### How to Load the Mod in The Forest
Simply launch **The Forest** normally through **Steam** (or `TheForest.exe`) and click **Play!** on the resolution selector. BepInEx automatically loads `TheForestDropkickMod.dll` at startup—no external mod launcher is required.

---

## 5. Configuration

Edit `C:\Program Files (x86)\Steam\steamapps\common\The Forest\BepInEx\config\com.theforest.dyinglightdropkick.cfg` with any text editor (changes are hot-reloaded automatically, even while the game is running):

- `DropkickKey = E`
- `InteractionKey = V`
- `DropkickEnabled = true`
- `SprintMomentumBonus = true`
- `DropkickDamage = 42`
- `DropkickForce = 7.2`
- `EnemyKnockbackForce = 10.5`
- `HeavyMutantKnockbackMultiplier = 0.32`
- `DropkickDuration = 0.54`
- `Cooldown = 1.2`
- `StaminaConsumption = true`
- `StaminaCost = 16`
- `CameraShake = Low` (`Off`, `Low`, `Medium`, `High`)
- `DebugLogging = false`

---

## 6. Uninstallation & Keybinding Restoration

To uninstall the mod and immediately restore default `E` interactions:
1. Run the included uninstaller script:
   ```powershell
   powershell -ExecutionPolicy Bypass -File "C:\Users\aarna\Downloads\TheForestDropkickMod\uninstall.ps1"
   ```
   *(Add `-RemoveBepInExLoader` if you also want to remove BepInEx itself).*
2. **Or manually delete**:
   - `BepInEx\plugins\TheForestDropkickMod\TheForestDropkickMod.dll`
   - `BepInEx\config\com.theforest.dyinglightdropkick.cfg`
3. Because the mod intercepts `InputMapping.SaveAllMaps` and restores original keys before `PlayerPrefs` is saved, removing the DLL or setting `DropkickEnabled = false` in the config immediately leaves all original `E` bindings intact without needing to reset controls in options.

---

## 7. Debugging Information

- **Log File Location**: `C:\Program Files (x86)\Steam\steamapps\common\The Forest\BepInEx\LogOutput.log`
- Set `DebugLogging = true` in `BepInEx\config\com.theforest.dyinglightdropkick.cfg` to log every Rewired action remap, dropkick activation/block reason, sprint momentum multiplier, bone resolution status, and enemy hit/damage/knockback calculation.
